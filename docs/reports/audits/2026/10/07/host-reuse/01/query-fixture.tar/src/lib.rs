pub mod test_support;
pub mod cache_file {
    use std::{io, path::PathBuf};
    #[derive(Debug)]
    pub enum CacheFileError {
        CreateDirectory { path: PathBuf, source: io::Error },
        WriteTemp { path: PathBuf, source: io::Error },
        WriteOutput { path: PathBuf, source: io::Error },
        SyncOutput { path: PathBuf, source: io::Error },
        OutputAliasesManagedPath { output_path: PathBuf, managed_path: PathBuf },
    }
    pub mod write {
        mod path;
        mod output;
        pub use output::{validate_output_path, write_text_output};
        #[cfg(test)]
        mod tests;
    }
}
